# Twiggy

A clean and minimal child theme for the [Stargazer](http://wordpress.org/themes/stargazer) parent theme. This child theme uses a thinner font to completely transform how its parent theme looks.  It offers an alternative color scheme and comes packaged with additional backgrounds to use with the WordPress custom background feature.

## Copyright and License

All resources and theme elements are licensed under the [GNU GPL](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html), version 2 or later.

2014 &copy; [Justin Tadlock](http://justintadlock.com).

## Changelog

### Version 1.0.0

* Everything's new!